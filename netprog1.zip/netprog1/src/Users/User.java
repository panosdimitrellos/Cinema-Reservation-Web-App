package Users;

public class User {
	
	private String username;
	private String password;
	private String property;
	private String name;
	
	public User(String aName,String anUsername,String aPassword) {
		name=aName;
		username=anUsername;
		password=aPassword;
		
	}
	
	public String getName() {
		return name;
	}
	
	public String getUsername() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setUsername(String anUsername) {
		username=anUsername;
	}
	
	public void setPassword(String aPassword) {
		password=aPassword;
	}
	
	public void setName(String aName) {
		name=aName;
	}
	public void login() {
		
	}
	
	public void logout() {
		
		System.out.println("successful logout");
	}
	
	public String getProperty() {
		return property;
	}
	
	
	
}
