package Users;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Admin extends User {


	
	
	public Admin(String aName,String anUsername,String aPassword) {
		super(aName,anUsername,aPassword);
	}


	public void createUser(User anUser) {
		
		String name=anUser.getName();
		String username=anUser.getUsername();
		String password=anUser.getPassword();
		String property=anUser.getProperty();
		
		String line=null; 
		
		
		boolean alreadyExists=false;
		if(property=="customer") {
			try {
				
				BufferedReader br=new BufferedReader(new FileReader("customers.txt"));
				
					
					
				
			
				while((line=br.readLine())!=null && alreadyExists==false) {
				
				
				alreadyExists=(line.equals(username+"-"+password));
				
				
				}
				br.close();
				if(alreadyExists==false) {
					PrintWriter pw=new PrintWriter(new FileOutputStream("customers.txt",true));
					pw.append(username+"-"+password);
					pw.println();
					
					pw.close();
					System.out.println(name+" ����������� ��� ������� �� username: "+username);
				}
					
				else
					System.out.println("�� username ������� ���");
				
				
		
			}catch(IOException e) {
				e.printStackTrace();
			}
		
		}
		else if(property=="contentAdmin") {
			try {
				
				BufferedReader br=new BufferedReader(new FileReader("contentAdmins.txt"));
				
					
					
					
			
				while((line=br.readLine())!=null && alreadyExists==false) {
				alreadyExists=(line.equals(username+"-"+password));
				
				}
				br.close();
				if(alreadyExists==false) {
					PrintWriter pw=new PrintWriter(new FileOutputStream("contentAdmins.txt",true));
					pw.append(username+"-"+password);
					pw.println();
					
					pw.close();
					System.out.println(name+" ����������� ��� contentAdmin �� username: "+username);
				}
					
				else
					System.out.println("To username ������� ���");
				
		}catch(IOException e) {
				e.printStackTrace();
			}
		
			
		}
		
		
		
	}

	public void updateUser(User anUser,String newProperty) {
		this.deleteUser(anUser);
		String line=anUser.getUsername()+"-"+anUser.getPassword();
		String currentLine;
		String property=anUser.getProperty();
		boolean alreadyExists=false;
		
		if(property.equals(newProperty))
			System.out.println("������ ��� ��������� ��������");
		else {
			if(newProperty.equals("contentAdmin")) {
				
				BufferedReader br;
				try {
					br = new BufferedReader(new FileReader("contentAdmins.txt"));
					while((currentLine=br.readLine())!=null && alreadyExists==false) {
						alreadyExists=currentLine.equals(line);
					}
					
				
				
				
				
				
				
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
				if(alreadyExists==false) {
				
				PrintWriter pw;
				try {
					pw = new PrintWriter(new FileOutputStream("contentAdmins.txt",true));
					pw.append(line);
					pw.println();
				
					pw.close();
					System.out.println(anUser.getName()+" ����� ����� ���� contentAdmin");
				
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
				
			}else if(newProperty.equals("admin")) {
				
				
				BufferedReader br;
				try {
					br = new BufferedReader(new FileReader("admins.txt"));
					while((currentLine=br.readLine())!=null && alreadyExists==false) {
						alreadyExists=currentLine.equals(line);
					}
					
				
				
				
				
				
				
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
				if(alreadyExists==false) {
				
				PrintWriter pw;
				try {
					pw = new PrintWriter(new FileOutputStream("admins.txt",true));
					pw.append(line);
					pw.println();
				
					pw.close();
					
					System.out.println(anUser.getName()+" ����� ����� ���� Admin");
				
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
		
  }
	
	public void deleteUser(User anUser) {
		String existingLine=anUser.getUsername()+"-"+anUser.getPassword();
		String line="";
		String property=anUser.getProperty();
		ArrayList<String>newUsers=new ArrayList<String>();
		if(property=="customer") {
			
			try {
				BufferedReader br=new  BufferedReader(new FileReader("customers.txt"));
				while((line=br.readLine())!=null) {
					if(!line.isEmpty()) {
						
						if(!line.equals(existingLine)) {
							newUsers.add(line);
						
							}	
				 }
			
			 }
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		try {
			FileWriter writer=new FileWriter("customers.txt");
			for(String user:newUsers) {
				writer.write(user);
				writer.write(System.lineSeparator());
				
			}
			writer.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		}else  if(property=="contentAdmin") {
			try {
				BufferedReader br=new  BufferedReader(new FileReader("contentAdmins.txt"));
				while((line=br.readLine())!=null) {
					if(!line.isEmpty()) {
						
						if(!line.equals(existingLine)) {
							newUsers.add(line);
						
							
					    
						}	
				
				   }
			
			
			   }
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		try {
			FileWriter writer=new FileWriter("contentAdmins.txt");
			for(String user:newUsers) {
				writer.write(user);
				writer.write(System.lineSeparator());
				
			}
			writer.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
			
		}else  if(property=="Admin") {
			try {
				BufferedReader br=new  BufferedReader(new FileReader("Admins.txt"));
				while((line=br.readLine())!=null) {
					if(!line.isEmpty()) {
						
						if(!line.equals(existingLine)) {
							newUsers.add(line);
						
							
					    
						}	
				
				   }
			
			
			   }
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		try {
			FileWriter writer=new FileWriter("Admins.txt");
			for(String user:newUsers) {
				writer.write(user);
				writer.write(System.lineSeparator());
				
			}
			writer.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
			
		}
		System.out.println("�������� �������� ��� ������ "+anUser.getName());
		
	}
	
	public void searchUser(User anUser) {
		String username=anUser.getUsername();
		String password=anUser.getPassword();
		String property=anUser.getProperty();
		String line="";
		int counter=0;
		
		if(property=="customer") {
			
			
			BufferedReader br=null;
			try {
				br=new BufferedReader(new FileReader("customers.txt"));
				 
				while((line=br.readLine())!=null) {
					if(!line.isEmpty()) {
						counter++;
						if(line.equals(username+"-"+password)) {
						System.out.println("O ������� ��� ������� ����� ���� ������"+counter+" �� username: "+username);
							
					    
						}
						
					}
					 
				}
				br.close();
			}catch (IOException e) {
				e.printStackTrace();
				
			}
			
			
		}else if(property=="contentAdmin") {
			
 
			
			
			BufferedReader br=null;
			try {
				br=new BufferedReader(new FileReader("contentAdmins.txt"));
				 
				
				
				while((line=br.readLine())!=null) {
				
				
					
				
					if(!line.isEmpty()) {
						counter++;
						if(line.equals(username+"-"+password)) {
							System.out.println("O contentAdmin ��� ������� ����� ���� ������"+counter+" �� username: "+username);
							
					    
						}
						
					}
					
				}
				br.close();
			}catch (IOException e) {
				e.printStackTrace();
				
			}
			
		}
	
	
}
				    
				     
				     
	public void viewAllUsers(String typeOfUser) {
		
		String line="";
		if(typeOfUser=="customer") {
	     System.out.println("�� ������� ����� ��:");
				
		BufferedReader br=null;
		
		try {
			br=new BufferedReader(new FileReader("customers.txt"));
			try {
				while(( line=br.readLine())!=null) {
					String temp[]=line.split("-");
				
					if(!line.isEmpty()) {
						System.out.println(temp[0]);
							
					    
						}
						
					}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
				} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}else if(typeOfUser=="contentAdmin") {
			System.out.println("�� contentAdmins ����� ��:");
		BufferedReader br=null;
		
		try {
			br=new BufferedReader(new FileReader("contentAdmins.txt"));
			try {
				while(( line=br.readLine())!=null) {
					String temp[]=line.split("-");
				
					
				
					if(!line.isEmpty()) {
						System.out.println(temp[0]);
							
					    
						}
						
					}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			
		
		
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}else if(typeOfUser=="Admin") {
		System.out.println("�� Admins ����� ��:");
	BufferedReader br=null;
	
	try {
		br=new BufferedReader(new FileReader("Admins.txt"));
		try {
			while(( line=br.readLine())!=null) {
				String temp[]=line.split("-");
			
				
			
				if(!line.isEmpty()) {
					System.out.println(temp[0]);
						
				    
					}
					
				}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	
	
	
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     }
		
		
	}
	
	public void registerAdmin() {
		String line ="";
		boolean alreadyExists=false;
		
		String username=this.getUsername();
		String password=this.getPassword();
		try {
			
			BufferedReader br=new BufferedReader(new FileReader("admins.txt"));
			
			while((line=br.readLine())!=null && alreadyExists==false) {
			
			alreadyExists=(line.equals(username+"-"+password));
			
			
			}
			br.close();
			if(alreadyExists==false) {
				PrintWriter pw=new PrintWriter(new FileOutputStream("admins.txt",true));
				pw.append(username+"-"+password);
				pw.println();
				
				pw.close();
				System.out.println("�������� ������� �� �����:"+username);
			}
				
			else
				System.out.println("�� username ������� ���");
			
				}catch(IOException e) {
			e.printStackTrace();
		}
	
		
		
		
	}
		
 
public void login() {
	String line="";
	
	boolean find=false;
	
	BufferedReader br=null;
		try {
			br=new BufferedReader(new FileReader("admins.txt"));
			 
			
			
			while((line=br.readLine())!=null&&find==false) {
				
			
				
			
				
					find=(line.equals(this.getUsername()+"-"+this.getPassword()));
			
			}
				if(find==true) 
					System.out.println("successful login");
				else
					System.out.println("not find this user");
				
			
			br.close();
		}catch (IOException e) {
			e.printStackTrace();
			
		}
		
		
	
  }
}
