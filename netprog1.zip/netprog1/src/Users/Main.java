package Users;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		 
		Admin A1=new Admin("fotis","fotis99","1234");
		A1.registerAdmin();
		
	
		ContentAdmin CA1=new ContentAdmin("panos","panos99","12345");
		A1.createUser(CA1);
				
		Customer C1=new Customer("xristos","xristos99","657");
		A1.createUser(C1);
				
		Customer C2=new Customer("tasos","tassos99","877");
		A1.createUser(C2);
		
		A1.updateUser(C1, "contentAdmin");
		
		A1.searchUser(C2);
		
		
		Customer C3=new Customer("rigakis","rig","34566");
		A1.createUser(C3);
		
		A1.viewAllUsers("customer");
		
		Film F1=new Film("01","papei");
		CA1.insertFilm(F1);
		
	
		Cinema Cin1=new Cinema("01",true,12);
		CA1.InstertCinema(Cin1);
		
		Provoli PR1=new Provoli(Cin1,F1);
		
		CA1.assignFilmToCinema(PR1);
		
		C2.showAvailableFilms();
		
		C2.filmInfo(PR1);
		
		C2.makeReservation(PR1, 12);
		C3.makeReservation(PR1, 1);
		
		C2.viewReservation();
		
		
		
		
		
		
		
		
		
		
		

	}

}
