package Users;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Customer extends User {
	private int numberOfTickets;
	
	public Customer(String aName,String anUsername,String aPassword) {
		super(aName,anUsername,aPassword);
	}
	
	public void showAvailableFilms()
	{

		System.out.println("O� ������� ��� ��������� �����: ");
		String line="";
		
		BufferedReader br=null;
		
			try {
				br=new BufferedReader(new FileReader("AvailableFilms.txt"));
				while(( line=br.readLine())!=null) {
					
					System.out.println(line);
				
					
				
				
						}
			
			
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				
			
				
			
		
		
		
		 

	}
	public void filmInfo(Provoli aProvoli) {
		if(this.searchFilminAvailableFilms(aProvoli.getProvFilm())==true) {
			System.out.println("�� ����������� ��� ������� "+aProvoli.getProvFilm().getFilmTitle()+" �����");
			System.out.println("E���� 3d: "+aProvoli.getProvCinema().getcinemaIs3D());
			System.out.println("��������� : "+aProvoli.getProvFilm().getFilmCategory());
			System.out.println("���������: "+aProvoli.getProvFilm().getFilmDescription());
			System.out.println("id ������ "+aProvoli.getProvCinema().getCinemaID());
			
			
			
			
		}
		
	}
	public boolean searchFilminAvailableFilms(Film aFilm) {
		boolean alreadyExists=false;
		String currentLine;
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader("AvailableFilms.txt"));
			while((currentLine=br.readLine())!=null && alreadyExists==false) {
				alreadyExists=currentLine.equals(aFilm.getFilmTitle());
			}
			
		
		
		
		
		
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return alreadyExists;
		
	}
   
	
	public void makeReservation(Provoli aProvoli,int numOftickets) {
		
		numberOfTickets=numOftickets;
		if(this.searchFilminAvailableFilms(aProvoli.getProvFilm())==true) {
			if(aProvoli.getProvCinema().getcinemaNumOfSeats()>=numberOfTickets) {
				System.out.println("�������� "+numOftickets+" ��������� ����44 ��� ������ "+aProvoli.getProvFilm().getFilmTitle()+" ��� ������ "+aProvoli.getProvCinema().getCinemaID());
				aProvoli.getProvCinema().releaseNumOfSeats(numberOfTickets);
			
			
				PrintWriter pw;
				try {
					pw = new PrintWriter(new FileOutputStream("Reservations.txt",true));
					pw.append(this.getUsername()+","+aProvoli.getProvFilm().getFilmTitle()+","+numOftickets);
					pw.println();
				
					pw.close();
					System.out.println("�������� ������� ��� ��� ������� ��� ������ "+aProvoli.getProvFilm().getFilmTitle()+" ��� ������ �� id+ "+aProvoli.getProvCinema().getCinemaID());
				
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			
			
			
			
			}else {
				
				System.out.println("��� �������� ���� ��������� ���������");
			}
				
			
		}
		
		
		
		
		
	}
	
	public void viewReservation() {
	String line;
		try {
			System.out.println("�� ��������� ��� �����:");
			BufferedReader br=new  BufferedReader(new FileReader("Reservations.txt"));
			while(( line=br.readLine())!=null) {
				
					
				String temp[]=line.split(",");
				if(temp[0].equals(this.getUsername())) {
					
					System.out.println(line  );
				}
				
				
			
			   
		
		
		   }
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public String getProperty() {
		return "customer";
	}
	
	public void login() {
		String line="";
		
		boolean find=false;
		
	
			
			
			BufferedReader br=null;
			try {
				br=new BufferedReader(new FileReader("customers.txt"));
				 
				
				
				while((line=br.readLine())!=null&&find==false) {
					
				
					
				
					
						find=(line.equals(this.getUsername()+"-"+this.getPassword()));
				
				}
					if(find==true) 
						System.out.println("successful login");
					else
						System.out.println("not find this user");
					
				
				br.close();
			}catch (IOException e) {
				e.printStackTrace();
				
			}
			
			
		
	}
}
	
