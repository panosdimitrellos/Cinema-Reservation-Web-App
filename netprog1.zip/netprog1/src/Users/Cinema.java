package Users;

public class Cinema {
	
	private String cinemaID;
	private boolean cinemaIs3D;
	private int cinemaNumberOfSeats;
	
	public Cinema(String anID,boolean is3D,int numOfSeats) {
		cinemaID=anID;
		cinemaIs3D=is3D;
		cinemaNumberOfSeats=numOfSeats;
	}
	
	public String getCinemaID() {
		return cinemaID;
	}
	
	public boolean getcinemaIs3D() {
		return cinemaIs3D;
	}
	
	public int getcinemaNumOfSeats() {
		return cinemaNumberOfSeats;
	}
	
	public void setCinemaID(String anID) {
		cinemaID=anID;
	}
	
	public void setCinemaIS3D(Boolean is3D) {
		cinemaIs3D=is3D;
		
	}
	
	public void setNumOfSeats(int aNum) {
		cinemaNumberOfSeats=aNum;
	}
	
	public void releaseNumOfSeats(int num) {
		cinemaNumberOfSeats=-num;
	}

}
