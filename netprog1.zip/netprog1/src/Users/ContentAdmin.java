package Users;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.lang.*; 

public class ContentAdmin extends User {
	
	public ContentAdmin(String aName,String anUsername,String aPassword) {
		super(aName,anUsername,aPassword);
	}

	
	public void insertFilm(Film aFilm) {
	  
		if (this.searchFilminInsertedFilms(aFilm)==false) {
		
		PrintWriter pw;
		try {
			pw = new PrintWriter(new FileOutputStream("InsertedFilms.txt",true));
			pw.append(aFilm.getFilmTitle());
			pw.println();
		
			pw.close();
			System.out.println("� ������ �� ����� "+aFilm.getFilmTitle()+" ��������� ��� InsertedFilms.txt ");
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}else
			System.out.println("� ������ ������� ���");
		
		
		
	}
	
	public void deleteFilm(Film aFilm) {
		ArrayList<String>filmTitles=new ArrayList<String>();
		
			String title=aFilm.getFilmTitle();
			String line;
			try {
				BufferedReader br=new  BufferedReader(new FileReader("InsertedFilms.txt"));
				while((line=br.readLine())!=null) {
					if(!line.isEmpty()) {
						
						if(!line.equals(title)) {
							filmTitles.add(line);
						}	
				
				   }
			
			
			   }
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
try {
			FileWriter writer=new FileWriter("InsertedFilms.txt");
			for(String film:filmTitles) {
				writer.write(film);
				writer.write(System.lineSeparator());
				
			}
			writer.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}
	
	public void InstertCinema(Cinema aCinema) {
		
			
			if(this.searchCinema(aCinema)==false) {
			
			PrintWriter pw;
			try {
				pw = new PrintWriter(new FileOutputStream("Cinemas.txt",true));
				pw.append(aCinema.getCinemaID());
				pw.println();
			
				pw.close();
				System.out.println("�� ������ �� id "+aCinema.getCinemaID()+" ��������� ��� cinemas.txt");
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}else
				System.out.println("To ������ ������� ���");
			
	}
	
	
	
	public boolean searchFilminInsertedFilms(Film aFilm) {
		boolean alreadyExists=false;
		String currentLine;
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader("InsertedFilms.txt"));
			while((currentLine=br.readLine())!=null && alreadyExists==false) {
				alreadyExists=currentLine.equals(aFilm.getFilmTitle());
			}
			
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return alreadyExists;
		
	}

	public boolean searchFilminAvailable(Film aFilm) {
		boolean alreadyExists=false;
		String currentLine;
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader("AvailableFilms.txt"));
			while((currentLine=br.readLine())!=null && alreadyExists==false) {
				alreadyExists=currentLine.equals(aFilm.getFilmTitle());
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return alreadyExists;
		
	}
	
	
	
	public void deleteCinema(Cinema aCinema) {
		ArrayList<String>CinemasID=new ArrayList<String>();
		
		String cinemaID=aCinema.getCinemaID();
		String line;
		try {
			BufferedReader br=new  BufferedReader(new FileReader("Cinemas.txt"));
			while((line=br.readLine())!=null) {
				if(!line.isEmpty()) {
					
					if(!line.equals(cinemaID)) {
						CinemasID.add(line);
					
						}	
			
			   }
		
		
		   }
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
		FileWriter writer=new FileWriter("Cinemas.txt");
		for(String cinID:CinemasID) {
			writer.write(cinID);
			writer.write(System.lineSeparator());
			
		}
		writer.close();
		
	} catch (IOException e) {
		
		e.printStackTrace();
	}
	System.out.println("To ������ �� id "+aCinema.getCinemaID()+" ����������");
		
	}
	
	public boolean searchCinema(Cinema aCinema) {
		
		boolean alreadyExists=false;
		String currentLine;
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader("Cinemas.txt"));
			while((currentLine=br.readLine())!=null && alreadyExists==false) {
				alreadyExists=currentLine.equals(aCinema.getCinemaID());
			}
			
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return alreadyExists;
		
	}
	
	
	
	
	
	public void assignFilmToCinema(Provoli aProv) {
		
	if(this.searchCinema(aProv.getProvCinema())==true&&this.searchFilminInsertedFilms(aProv.getProvFilm())==true) {
			
			if(this.searchFilminAvailable(aProv.getProvFilm())==false) {
			
			PrintWriter pw;
			try {
				pw = new PrintWriter(new FileOutputStream("AvailableFilms.txt",true));
				pw.append(aProv.getProvFilm().getFilmTitle());
				pw.println();
			
				pw.close();
				System.out.println("H ������ "+aProv.getProvFilm().getFilmTitle() +" ����� ��������� ��� ������� ��� ������ "+aProv.getProvCinema().getCinemaID());
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			}else
				System.out.println("� ������� ����� ���� ��� ������������");
			
		}
	
	}	
		
		
	
	
	public String getProperty() {
		return "contentAdmin";
	}
	public void login() {
		String line="";
		
		boolean find=false;
		
	
			
			
			BufferedReader br=null;
			try {
				br=new BufferedReader(new FileReader("contentAdmins.txt"));
				 
				
				
				while((line=br.readLine())!=null&&find==false) {
					
				
					
				
					
						find=(line.equals(this.getUsername()+"-"+this.getPassword()));
				
				}
					if(find==true) 
						System.out.println("successful login");
					else
						System.out.println("not find this user");
					
				
				br.close();
			}catch (IOException e) {
				e.printStackTrace();
				
			}
			
			
		
	}
}
	

