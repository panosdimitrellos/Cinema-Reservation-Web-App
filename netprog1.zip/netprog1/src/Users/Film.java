package Users;

public class Film {
	
	private String filmID;
	private String filmTitle;
	private String filmCategory;
	private String filmDescription;
	
	public Film(String anID,String aTitle) {
		filmID=anID;
		filmTitle=aTitle;
		
	}
	
	public String getFilmID(){
		return filmID;
	}

	public String getFilmTitle() {
		return filmTitle;
	}
	
	public String getFilmCategory() {
		return filmCategory;
	}
	
	public String getFilmDescription() {
		return filmDescription;
	}
	
	public void setFilmID(String anID) {
		filmID=anID;
	}
	
	public void setFilmTitle(String aTitle) {
		filmTitle=aTitle;
	}
	
	public void setFilmCategory(String aCategory) {
		filmCategory=aCategory;
	}
	
	public void setFilmDescription(String aDescription) {
		filmDescription=aDescription;
	}
	
}
