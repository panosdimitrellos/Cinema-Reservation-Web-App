package Users;



public class Provoli {
	
	
	
	
	
	private Cinema aCinema;
	private Film aFilm;
	
	public Provoli(Cinema aCin,Film aFil) {
		aCinema=aCin;
		aFilm=aFil;
	}
	
	public Film getProvFilm() {
		return aFilm;
	}
	
	public Cinema getProvCinema() {
		return aCinema;
	}



}
	

	 
	
						

