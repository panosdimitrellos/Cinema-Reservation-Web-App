package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet2
 */
@WebServlet("/servlet2")
public class servlet2 extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text.html");
		PrintWriter writer=response.getWriter();
		String option=request.getParameter("selector");
	
		
	
		if (option.equals("a")) {
			response.sendRedirect("jspShowFilms.jsp");
			
		}else if(option.equals("b")){
			response.sendRedirect("makeProvoli.html");
		}else if(option.equals("c")) {
			response.sendRedirect("insertFilm.html");
			
		}else if(option.equals("d")) {
			response.sendRedirect("changeFilm.html");
			
		}
		
	}

}
