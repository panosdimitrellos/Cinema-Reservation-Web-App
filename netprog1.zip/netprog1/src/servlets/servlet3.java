package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet3
 */
@WebServlet("/servlet3")
public class servlet3 extends HttpServlet {
	
  
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text.html");
		PrintWriter writer=response.getWriter();
		String title=request.getParameter("title");
		String id=request.getParameter("id");
		String description=request.getParameter("description");
		String category=request.getParameter("category");
		
		request.getSession().setAttribute("id", id);
		request.getSession().setAttribute("title",title);
		request.getSession().setAttribute("category",category);
		request.getSession().setAttribute("description",description);
		
		try {
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/netprog","postgres","123456");
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select* from films");
			 
			 boolean found=false;
				while(rs.next()&&found==false) {
					if(rs.getString(1).equals(id)) {
						found=true;
						response.sendRedirect("jspSameid.jsp");
					}
				}
			String query="insert into films values('"+id+"','"+title+"','"+category+"','"+description+"');";
			stm.executeUpdate(query);
			response.sendRedirect("jspInsert.jsp");
			
			}catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

	}
}
