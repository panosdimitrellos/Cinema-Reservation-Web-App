package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet8
 */
@WebServlet("/servlet8")
public class servlet8 extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text.html");
		PrintWriter writer=response.getWriter();
		
		String provoli_id=request.getParameter("id");
		 java.util.Date date01=null;
			try {
				date01 = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("startDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			 java.sql.Date date1 = new java.sql.Date(date01.getTime());
				
			 java.util.Date date02=null;
			try {
				date02 = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("endDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			 java.sql.Date date2 = new java.sql.Date(date02.getTime());

			 if (date1.compareTo(date2) > 0 ) {
		          
				 response.sendRedirect("jspWrongDates.jsp");
			 }	
		
		try{
			
		Class.forName("org.postgresql.Driver");
		Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/netprog","postgres","123456");
		
		Statement stm=con.createStatement();
		ResultSet rs=stm.executeQuery("select* from provoles");

		Statement stm2=con.createStatement();
		 boolean found=false;
			while(rs.next()&&found==false) {
				
				if(rs.getString(1).equals(provoli_id)) {
					
					//String query="update provoles set provoli_startdate='"+date1+"', provoli_enddate='"+date2+"'where provoli_id='"+provoli_id+"';";
					//stm2.executeQuery(query);
					PreparedStatement st = con.prepareStatement("update provoles set provoli_startdate=?,provoli_enddate=? where provoli_id=?");
					
					st.setDate(1, date1);
					st.setDate(2, date2);
					st.setString(3, provoli_id);
					st.executeUpdate(); 
					found=true;
					System.out.println("yes");
					request.getSession().setAttribute("id", provoli_id);
					response.sendRedirect("showChange.jsp");
				}
				
				}if(found==false) {
					response.sendRedirect("errorChange.jsp");
				}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		}	catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
	}

}
