package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet4
 */
@WebServlet("/servlet4")
public class servlet4 extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text.html");
		PrintWriter writer=response.getWriter();
		String film=request.getParameter("film");
		String cinema=request.getParameter("cinema");
		String time=request.getParameter("time");
		String id=request.getParameter("id");
	 java.util.Date date01=null;
	try {
		date01 = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("start"));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	 java.sql.Date date1 = new java.sql.Date(date01.getTime());
		
	 java.util.Date date02=null;
	try {
		date02 = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("end"));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	 java.sql.Date date2 = new java.sql.Date(date02.getTime());
	
		
		int numOfReservs=0;
		
		
		request.getSession().setAttribute("film", film);
		request.getSession().setAttribute("cinema",cinema);
		request.getSession().setAttribute("time",time);
		request.getSession().setAttribute("id",id);
		request.getSession().setAttribute("start",date1);
		request.getSession().setAttribute("end",date2);
		
		 if (date1.compareTo(date2) > 0 ) {
	          
			 response.sendRedirect("jspWrongDates.jsp");
		 }
		
		 
		 java.util.Date currentDate=new  java.util.Date();
		 if (currentDate.compareTo(date1) > 0 ) {
			 response.sendRedirect("jspWrongDates2.jsp"); 
		 }
		 
		 
		try {
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/netprog","postgres","123456");
			System.out.println("connected");

			Statement stmt0=con.createStatement();
			ResultSet rs=stmt0.executeQuery("select* from provoles");
			boolean idfound=false;
			while(rs.next()&&idfound==false) {
				if(rs.getString(1).equals(id)) {
					idfound=true;
					response.sendRedirect("sameId.jsp");
				}
			}
			
			

			Statement stmt5=con.createStatement();
			ResultSet rs5=stmt5.executeQuery("select* from provoles");
			boolean same=false;
			String time2;
			while(rs5.next()&& same==false) {
				time2=rs5.getTime(7).toString();
				if((rs5.getString(3).equals(cinema)&& rs5.getDate(4).equals(date1)&&time2.equals(time))||rs5.getString(3).equals(cinema)&& rs5.getDate(4).equals(date2)&&time2.equals(time)||
						(rs5.getString(3).equals(cinema)&& rs5.getDate(5).equals(date1)&&time2.equals(time))||(rs5.getString(3).equals(cinema)&& rs5.getDate(5).equals(date2))&&time2.equals(time)) {
					same=true;
					response.sendRedirect("jspCinemaNotAvailable.jsp");
				}
			}
			
			Statement stmt2=con.createStatement();
			Statement stmt=con.createStatement();
			ResultSet rs1=stmt.executeQuery("select* from films");
			ResultSet rs2=stmt2.executeQuery("select* from cinemas");
			boolean found1=false;
			while(rs1.next() &&found1==false) {
				if(rs1.getString(1).equals(film)) {
					found1=true;}
			}
			
			boolean found2=false;
			while(rs2.next() &&found2==false) {
				if(rs2.getString(1).equals(cinema)) {
					found2=true;}
			}
			
			
			
			
			if(found1==true&&found2==true) {
			
			Statement stm=con.createStatement();
			String query="insert into provoles values('"+id+"','"+film+"','"+cinema+"','"+date1+"','"+date2+"','"+numOfReservs+"','"+time+"');";
			stm.executeUpdate(query);
			System.out.println("data inserted");
			response.sendRedirect("jspProvoli.jsp");
			}else {
				response.sendRedirect("jspFailprovoli.jsp");
			}
		
		
		
		
		}catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

		
	}

	

}
