package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet6
 */
@WebServlet("/servlet6")
public class servlet6 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text.html");
		PrintWriter writer=response.getWriter();
		String username=request.getParameter("username");
		String id  ;
		String name;
		
		request.getSession().setAttribute("username",username);
		try {
		Class.forName("org.postgresql.Driver");
		Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/netprog","postgres","123456"); 
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select* from contentadmins");
		boolean found=false;
		while(rs.next()&&found==false) {
			if(rs.getString(3).equals(username)) {
				found=true;
				
				name=rs.getString(2);
				request.getSession().setAttribute("name",name);
				
				id=rs.getString(1);
				request.getSession().setAttribute("id",id);
				
				
				PreparedStatement st = con.prepareStatement("DELETE FROM contentadmins WHERE contentadmin_username = ?");
				st.setString(1,username);
				st.executeUpdate(); 
				
				response.sendRedirect("deleteCO.jsp");
				
		     
		
	
		
	
			}
		}if(found==false) {
			response.sendRedirect("deleteFail.jsp");
		}
		}catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	
	
	}

}
