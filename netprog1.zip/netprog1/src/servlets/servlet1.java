package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class servlet1
 */
@WebServlet("/servlet1")
public class servlet1 extends HttpServlet {
	
       
   
   

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text.html");
		PrintWriter writer=response.getWriter();
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String membership=request.getParameter("membership");
		String name;
		
		
		if(membership.equals("co")) {
			System.out.println("content");
			
		
		
		
		
		try {
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/netprog","postgres","123456");
			System.out.println("connected");
		 
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select* from contentadmins");
			boolean found=false;
			while(rs.next()&&found==false) {
				if(rs.getString(3).equals(username)&& rs.getString(4).equals(password)) {
					found=true;
					System.out.println("successful login");
				request.getSession().setAttribute("username", username);
				request.getSession().setAttribute("password",password);
				name=rs.getString(2);
				request.getSession().setAttribute("name",name);
				
				
				response.sendRedirect("jspLogin.jsp");
				
				
				}
				
			
			}
			if(found==false) {
				response.sendRedirect("jspWrongLogin.jsp");
				
			}
				
			
		}catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	
		
	}else if(membership.equals("admin")){

		try {
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/netprog","postgres","123456");
			System.out.println("connected");
		 
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select* from admins");
			boolean found=false;
			while(rs.next()&&found==false) {
				if(rs.getString(3).equals(username)&& rs.getString(4).equals(password)) {
					found=true;
					System.out.println("successful login");
				request.getSession().setAttribute("username", username);
				request.getSession().setAttribute("password",password);
				name=rs.getString(2);
				request.getSession().setAttribute("name",name);
				
				
				response.sendRedirect("Admins.jsp");
				
				
				}
				
			
			}
			if(found==false) {
				response.sendRedirect("jspWrongLogin.jsp");
				
			}
				
			
		}catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		

	}else if(membership.equals("customer")) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/netprog","postgres","123456");
			
		 
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select* from customers");
			boolean found=false;
			while(rs.next()&&found==false) {
				if(rs.getString(3).equals(username)&& rs.getString(4).equals(password)) {
					found=true;
					System.out.println("successful login");
				request.getSession().setAttribute("username", username);
				request.getSession().setAttribute("password",password);
				name=rs.getString(2);
				request.getSession().setAttribute("name",name);
				
				 HttpSession session = request.getSession();
			      session.setAttribute("user_id",rs.getString(1) );
				response.sendRedirect("customers.jsp");
				}
				
				
			}
			if(found==false) {
				response.sendRedirect("jspWrongLogin.jsp");
				
			}
				
			
		}catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
  }
}
				
			
	
