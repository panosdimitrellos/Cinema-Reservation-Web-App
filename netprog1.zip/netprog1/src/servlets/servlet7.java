package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




@WebServlet("/servlet7")
public class servlet7 extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text.html");
		PrintWriter writer=response.getWriter();
		String option=request.getParameter("selector");
		
		if (option.equals("a")) {
			String start=request.getParameter("startDate");
			String end=request.getParameter("endDate");
				
			request.getSession().setAttribute("start", start);
			request.getSession().setAttribute("end",end);
			 
			response.sendRedirect("ShowProvolesDate.jsp");
						
			
		}else if(option.equals("b")){
			
			String film_title=request.getParameter("filmTitle");
			
			
			
			
			
			
			try{
				
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/netprog","postgres","123456");
			
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select* from cinemas");
			
			Statement stm2=con.createStatement();
			ResultSet rs2=stm2.executeQuery("select* from provoles");
			
			Statement stm3=con.createStatement();
			ResultSet rs3=stm3.executeQuery("select* from films");
			
			
			boolean found3=false;
			boolean found2=false;
			 boolean found=false;
				while(rs3.next()&&found==false) {
					if(rs3.getString(2).equals(film_title)) {
						found=true;
						while(rs2.next()&&found2==false){
							if(rs2.getString(2).equals(rs3.getString(1))) {
								found2=true;
								while(rs.next()&&found3==false) {
									if(rs.getString(1).equals(rs2.getString(3))) {
										found3=true;
										if(rs2.getInt(6)<rs.getInt(3)) {
											int availableSeats=rs.getInt(3)-rs2.getInt(6);
											request.getSession().setAttribute("title", film_title);
											request.getSession().setAttribute("avseats", availableSeats);
											response.sendRedirect("availableFilm.jsp");
										
										}else {
											response.sendRedirect("NoavailableFilm.jsp");
										}
									}
							}
						}
					}
				}
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			}	catch (Exception ex) {
				System.out.println(ex.getMessage());
			}

		}else if(option.equals("c")) {
			
			// HttpSession session = request.getSession();
			//String data = (String) session.getAttribute("user");
			//System.out.println(data);
			
			
			String title=request.getParameter("title");
			
			
			int numOftickets=Integer.parseInt(request.getParameter("tickets"));
			java.util.Date date01=null;
			try {
				date01 = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			 java.sql.Date date = new java.sql.Date(date01.getTime());
			
		    String film_id;
			int numOfseats;
			int reserves;
			String id;
			try{
				
				Class.forName("org.postgresql.Driver");
				Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/netprog","postgres","123456");
				
				Statement stm=con.createStatement();
				ResultSet rs=stm.executeQuery("select* from cinemas");
				
				Statement stm2=con.createStatement();
				ResultSet rs2=stm2.executeQuery("select* from provoles");
			
				
				Statement stm3=con.createStatement();
				ResultSet rs3=stm3.executeQuery("select* from films");
				

				Statement stm5=con.createStatement();
				ResultSet rs5=stm5.executeQuery("select* from purchase");
				 
				Statement stm4=con.createStatement();
				int provoli_id=1;
				 
			int count=0;
				boolean found3=false;
				boolean found2=false;
				 boolean found=false;
					while(rs3.next()&&found==false) {
						if(rs3.getString(2).equals(title)) {
							found=true;
							film_id=rs3.getString(1);
							while(rs2.next()&&found2==false){
								if(rs2.getString(2).equals(rs3.getString(1))) {
									found2=true;
									while(rs.next()&&found3==false) {
										if(rs.getString(1).equals(rs2.getString(3))) {
											
											numOfseats=rs.getInt(3);
											reserves=rs2.getInt(6);
											 if ((date.compareTo(rs2.getDate(4)) >= 0) && (date.compareTo(rs2.getDate(5)) <= 0)) {
										          
												
											 
											
											if((numOftickets+reserves)<=numOfseats) {
												HttpSession session = request.getSession();
												 id = (String) session.getAttribute("user_id");
												 System.out.println("yes");
												 while(rs5.next()) {
													 count=count+1;
													 found3=true;
												 }
												 java.util.Date current=new  java.util.Date();
												 
												 java.sql.Date currentDate = new java.sql.Date(current.getTime());

												 provoli_id=count+1;
												 String query="insert into purchase values('"+provoli_id+"','"+id+"','"+rs2.getString(1)+"','"+numOftickets+"','"+currentDate+"');";
												stm4.executeUpdate(query);
												PreparedStatement st = con.prepareStatement("update provoles set provoli_numofreservations=?");
												
												st.setInt(1, numOftickets+reserves);
												
												st.executeUpdate(); 
												request.getSession().setAttribute("title", title);
												request.getSession().setAttribute("d3", rs.getString(2));
												request.getSession().setAttribute("date", date);
												request.getSession().setAttribute("num", numOftickets);
												request.getSession().setAttribute("time", rs2.getTime(7));
												response.sendRedirect("purchase.jsp");
												 
											}else 
												response.sendRedirect("Noenough.jsp");
												 
											}else
												response.sendRedirect("errorpurchase.jsp");
												
											
											
										}
											 
								}
							}
						}
							
								 	
					}
					}
				
					if (found==false)
						response.sendRedirect("noFilm.jsp");
					if (found2==false)
						response.sendRedirect("noProvoli.jsp");
					
		   }
				
				
		
	
				
			
			
			
			
			
			
			
			
			
				catch (Exception ex) {
				System.out.println(ex.getMessage());
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}else if(option.equals("d")) {
			String id;
			HttpSession session = request.getSession();
			 id = (String) session.getAttribute("user_id");
			 request.getSession().setAttribute("id",id);
			 response.sendRedirect("history.jsp");
			
		}
		
	}

}
